//
// Created by ‘CQISM’
// Copyright (c) 2018 ‘CQISM’. All rights reserved.
//

import Foundation

class MainViewModuleAPIDataManager: MainViewModuleAPIDataManagerInputProtocol
{
    init() {}
}