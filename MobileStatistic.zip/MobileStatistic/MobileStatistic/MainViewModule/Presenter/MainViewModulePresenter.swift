//
// Created by ‘CQISM’
// Copyright (c) 2018 ‘CQISM’. All rights reserved.
//

import Foundation

class MainViewModulePresenter: MainViewModulePresenterProtocol, MainViewModuleInteractorOutputProtocol
{
    
    weak var view: MainViewModuleViewProtocol?
    var interactor: MainViewModuleInteractorInputProtocol?
    var wireFrame: MainViewModuleWireFrameProtocol?
    var delegate: MainModuleDelegate?
    
    init() {}    
}



extension MainViewModulePresenter: MainModuleDelegate{
    
    func sendLoginUser(userName: String) {
        print("MainViewModulePresenter?.sendLoginUser: " + userName)
        let text = userName
        view?.updateLabel(text: text)
    }
    
}

