//
// Created by ‘CQISM’
// Copyright (c) 2018 ‘CQISM’. All rights reserved.
//

import Foundation

class MainViewModuleInteractor: MainViewModuleInteractorInputProtocol
{
    weak var presenter: MainViewModuleInteractorOutputProtocol?
    var APIDataManager: MainViewModuleAPIDataManagerInputProtocol?
    var localDatamanager: MainViewModuleLocalDataManagerInputProtocol?
    
    init() {}
}