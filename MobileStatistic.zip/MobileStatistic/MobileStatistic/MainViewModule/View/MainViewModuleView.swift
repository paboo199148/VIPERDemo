//
// Created by ‘CQISM’
// Copyright (c) 2018 ‘CQISM’. All rights reserved.
//

import Foundation
import UIKit

class MainViewModuleView: UIViewController, MainViewModuleViewProtocol
{

    var presenter: MainViewModulePresenterProtocol?
    
  
    @IBOutlet weak var userInfo: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        print(NSHomeDirectory()as NSString)
    }
    
    func updateLabel(text:String){
        print(text)
        userInfo.text = text
    }
}










