//
// Created by ‘CQISM’
// Copyright (c) 2018 ‘CQISM’. All rights reserved.
//

import Foundation
import UIKit

class MainViewModuleWireFrame: MainViewModuleWireFrameProtocol
{
    class func presentMainViewModule()->UIViewController
    {
        // Generating module components
        //let navController = mainStoryboard.instantiateViewController(withIdentifier: "MainViewModuleController")
        if let view = mainStoryboard.instantiateViewController(withIdentifier: "MainViewModuleController") as? MainViewModuleView {
            let presenter: MainViewModulePresenterProtocol & MainViewModuleInteractorOutputProtocol = MainViewModulePresenter()
            let interactor: MainViewModuleInteractorInputProtocol = MainViewModuleInteractor()
            let APIDataManager: MainViewModuleAPIDataManagerInputProtocol = MainViewModuleAPIDataManager()
            let localDataManager: MainViewModuleLocalDataManagerInputProtocol = MainViewModuleLocalDataManager()
            let wireFrame: MainViewModuleWireFrameProtocol = MainViewModuleWireFrame()
            
            // Connecting
            view.presenter = presenter
        
            presenter.view = view
            presenter.wireFrame = wireFrame
            presenter.interactor = interactor
            interactor.presenter = presenter
            interactor.APIDataManager = APIDataManager
            interactor.localDatamanager = localDataManager
            
            print("MainView")
            
            return view
        }
        return UIViewController()
    }
    
    static var mainStoryboard: UIStoryboard {
        return UIStoryboard(name: "Main", bundle: Bundle.main)
    }
}
