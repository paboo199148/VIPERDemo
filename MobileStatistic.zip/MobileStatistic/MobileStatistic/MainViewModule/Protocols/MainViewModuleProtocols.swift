//
// Created by ‘CQISM’
// Copyright (c) 2018 ‘CQISM’. All rights reserved.
//

import Foundation
import UIKit
import CoreData


protocol MainViewModuleViewProtocol: class
{
    var presenter: MainViewModulePresenterProtocol? { get set }
    /**
    * Add here your methods for communication PRESENTER -> VIEW
    */
    
    func updateLabel(text:String)
    
}

protocol MainViewModuleWireFrameProtocol: class
{
    static func presentMainViewModule() -> UIViewController
    /**
    * Add here your methods for communication PRESENTER -> WIREFRAME
    */
}

protocol MainViewModulePresenterProtocol: class
{
    var view: MainViewModuleViewProtocol? { get set }
    var interactor: MainViewModuleInteractorInputProtocol? { get set }
    var wireFrame: MainViewModuleWireFrameProtocol? { get set }
    var delegate: MainModuleDelegate? { get set }
    
    /**
    * Add here your methods for communication VIEW -> PRESENTER
    */
}

protocol MainViewModuleInteractorOutputProtocol: class
{
    /**
    * Add here your methods for communication INTERACTOR -> PRESENTER
    */
}

protocol MainViewModuleInteractorInputProtocol: class
{
    var presenter: MainViewModuleInteractorOutputProtocol? { get set }
    var APIDataManager: MainViewModuleAPIDataManagerInputProtocol? { get set }
    var localDatamanager: MainViewModuleLocalDataManagerInputProtocol? { get set }
    /**
    * Add here your methods for communication PRESENTER -> INTERACTOR
    */
}

protocol MainViewModuleDataManagerInputProtocol: class
{
    /**
    * Add here your methods for communication INTERACTOR -> DATAMANAGER
    */
}

protocol MainViewModuleAPIDataManagerInputProtocol: class
{
    /**
    * Add here your methods for communication INTERACTOR -> APIDATAMANAGER
    */
}

protocol MainViewModuleLocalDataManagerInputProtocol: class
{
    /**
    * Add here your methods for communication INTERACTOR -> LOCALDATAMANAGER
    */
}
