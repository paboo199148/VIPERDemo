//
// Created by ‘CQISM’
// Copyright (c) 2018 ‘CQISM’. All rights reserved.
//

import Foundation
import UIKit

class LoginModuleWireFrame: LoginModuleWireFrameProtocol
{
    class func presentLoginModule() -> UIViewController
    {
        // Generating module components
        if let view = mainStoryboard.instantiateViewController(withIdentifier: "LoginModuleViewController") as? LoginModuleView {
            let presenter: LoginModulePresenterProtocol & LoginModuleInteractorOutputProtocol = LoginModulePresenter()
            let interactor: LoginModuleInteractorInputProtocol = LoginModuleInteractor()
            let APIDataManager: LoginModuleAPIDataManagerInputProtocol = LoginModuleAPIDataManager()
            let localDataManager: LoginModuleLocalDataManagerInputProtocol = LoginModuleLocalDataManager()
            let wireFrame: LoginModuleWireFrameProtocol = LoginModuleWireFrame()
            
            // Connecting
            view.presenter = presenter
            presenter.view = view
            presenter.wireFrame = wireFrame
            presenter.interactor = interactor
            interactor.presenter = presenter
            interactor.APIDataManager = APIDataManager
            interactor.localDatamanager = localDataManager
            return view
        }
        return UIViewController()
    }
    
    
    //导航到MainView界面
    func presentMainViewScreen(from view: LoginModuleViewProtocol,userName: String) {
        
        print("presentMainViewScreen: " + userName)
      // let delegate = LoginModuleWireFrame.mainStoryboard.instantiateViewController(withIdentifier: "MainViewModuleController") as! MainViewModuleView
        let mainView = MainViewModuleWireFrame.presentMainViewModule()
        let delegate  = (mainView as! MainViewModuleView).presenter as! MainModuleDelegate
        delegate.sendLoginUser(userName: userName)
        if let sourceView = view as? UIViewController {
            sourceView.present(mainView, animated: true, completion: nil)
        }
    }
    
    
    static var mainStoryboard: UIStoryboard {
        return UIStoryboard(name: "Main", bundle: Bundle.main)
    }
}
