//
// Created by ‘CQISM’
// Copyright (c) 2018 ‘CQISM’. All rights reserved.
//

import Foundation
import UIKit
import CoreData

////ContactListPresenter<---->AddContactPresenter
protocol MainModuleDelegate: class{
    func sendLoginUser(userName: String)
}

protocol LoginModuleViewProtocol: class
{
    var presenter: LoginModulePresenterProtocol? { get set }
    var delegate: MainModuleDelegate? { get set }
    
    /**
    * Add here your methods for communication PRESENTER -> VIEW
    */
}

protocol LoginModuleWireFrameProtocol: class
{
    static func presentLoginModule()->UIViewController
    /**
    * Add here your methods for communication PRESENTER -> WIREFRAME
    */
    
    func presentMainViewScreen(from view: LoginModuleViewProtocol, userName: String)
}

protocol LoginModulePresenterProtocol: class
{
    var view: LoginModuleViewProtocol? { get set }
    var interactor: LoginModuleInteractorInputProtocol? { get set }
    var wireFrame: LoginModuleWireFrameProtocol? { get set }
    
    /**
    * Add here your methods for communication VIEW -> PRESENTER
    */
    
    func loginToSystem(from view: LoginModuleViewProtocol, userName: String, password: String)
    
}

protocol LoginModuleInteractorOutputProtocol: class
{
    /**
    * Add here your methods for communication INTERACTOR -> PRESENTER
    */
}

protocol LoginModuleInteractorInputProtocol: class
{
    var presenter: LoginModuleInteractorOutputProtocol? { get set }
    var APIDataManager: LoginModuleAPIDataManagerInputProtocol? { get set }
    var localDatamanager: LoginModuleLocalDataManagerInputProtocol? { get set }
    /**
    * Add here your methods for communication PRESENTER -> INTERACTOR
    */
    
    func saveLoginUser(userName: String, password: String) -> LoginUser?
}

protocol LoginModuleDataManagerInputProtocol: class
{
    /**
    * Add here your methods for communication INTERACTOR -> DATAMANAGER
    */
}

protocol LoginModuleAPIDataManagerInputProtocol: class
{
    /**
    * Add here your methods for communication INTERACTOR -> APIDATAMANAGER
    */
}

protocol LoginModuleLocalDataManagerInputProtocol: class
{
    /**
    * Add here your methods for communication INTERACTOR -> LOCALDATAMANAGER
    */
    
    func createLoginUser(userName: String, password: String) throws -> LoginUser
    
    
}
