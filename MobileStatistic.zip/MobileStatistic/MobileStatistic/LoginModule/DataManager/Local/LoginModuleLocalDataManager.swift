//
// Created by ‘CQISM’
// Copyright (c) 2018 ‘CQISM’. All rights reserved.
//

import Foundation
import CoreData

enum PersistenceError: Error {
    case managedObjectContextNotFound
    case couldNotCreateObject
    case objectNotFound
}


class LoginModuleLocalDataManager: LoginModuleLocalDataManagerInputProtocol
{
    init() {}
    
    func createLoginUser(userName: String, password: String) throws -> LoginUser {
        guard let managedOC = CoreDataStore.managedObjectContext else {
            throw PersistenceError.managedObjectContextNotFound
        }
        
        if let newLoginUser = NSEntityDescription.entity(forEntityName: "LoginUser",
                                                       in: managedOC) {
            let loginUser = LoginUser(entity: newLoginUser, insertInto: managedOC)
            loginUser.userName = userName
            loginUser.password = password
            try managedOC.save()
            return loginUser
        }
        throw PersistenceError.couldNotCreateObject
    }
    
}
