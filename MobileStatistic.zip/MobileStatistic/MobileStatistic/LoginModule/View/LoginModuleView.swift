//
// Created by ‘CQISM’
// Copyright (c) 2018 ‘CQISM’. All rights reserved.
//

import Foundation
import UIKit

class LoginModuleView: UIViewController, LoginModuleViewProtocol
{
    var presenter: LoginModulePresenterProtocol?
    var delegate: MainModuleDelegate?
    
    @IBOutlet weak var userNameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userNameTextField.becomeFirstResponder()
    }

    
    
    @IBAction func loginButtonAction(_ sender: UIButton) {
        
        guard
            let userName = userNameTextField.text,
            let password = passwordTextField.text
            else {
                return
        }
        
        if userName.isEmpty || password.isEmpty {
            showEmptyNameAlert()
            return
        }
        
        print("presenter?.loginToSystem")
        presenter?.loginToSystem(from: self, userName: userName, password: password)
    }
    
    
    
    //警告框
    fileprivate func showEmptyNameAlert() {
        let alertView = UIAlertController(title: "系统提示",
                                          message: "用户名或密码不能为空！",
                                          preferredStyle: .alert)
        alertView.addAction(UIAlertAction(title: "确定", style: .destructive, handler: nil))
        present(alertView, animated: true, completion: nil)
    }
}
