//
// Created by ‘CQISM’
// Copyright (c) 2018 ‘CQISM’. All rights reserved.
//

import Foundation

struct LoginModuleItem
{
    /**
    *  Attributes here
    */
}