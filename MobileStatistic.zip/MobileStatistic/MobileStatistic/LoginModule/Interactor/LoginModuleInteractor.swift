//
// Created by ‘CQISM’
// Copyright (c) 2018 ‘CQISM’. All rights reserved.
//

import Foundation

class LoginModuleInteractor: LoginModuleInteractorInputProtocol
{
    weak var presenter: LoginModuleInteractorOutputProtocol?
    var APIDataManager: LoginModuleAPIDataManagerInputProtocol?
    var localDatamanager: LoginModuleLocalDataManagerInputProtocol?
    
    init() {}
    
    func saveLoginUser(userName: String, password: String) -> LoginUser? {
        do {
            let loginUser = try localDatamanager?.createLoginUser(userName: userName, password: password)
            return loginUser
        } catch {
            return nil
        }
    }
    
    
    
}
