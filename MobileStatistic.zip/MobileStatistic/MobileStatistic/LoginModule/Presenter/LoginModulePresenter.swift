//
// Created by ‘CQISM’
// Copyright (c) 2018 ‘CQISM’. All rights reserved.
//

import Foundation

class LoginModulePresenter: LoginModulePresenterProtocol, LoginModuleInteractorOutputProtocol
{
    
    weak var view: LoginModuleViewProtocol?
    var interactor: LoginModuleInteractorInputProtocol?
    var wireFrame: LoginModuleWireFrameProtocol?
    
    init() {}
    
    func loginToSystem(from view: LoginModuleViewProtocol, userName: String, password: String) {
        
        print("wireFrame?.presentMainViewScreen")
        
        let loginUser = interactor?.saveLoginUser(userName: userName, password: password)
        wireFrame?.presentMainViewScreen(from: view, userName: userName)
        
    }

}



